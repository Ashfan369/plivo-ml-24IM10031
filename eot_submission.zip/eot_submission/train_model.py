"""Train the EOT model (blend of gradient-boosting variants, duration-
weighted holds) on english+hindi; write model.pkl for predict.py and
out-of-fold predictions for honest scoring."""
import csv
import os
import pickle

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import GroupKFold

from predict import build_matrix

DIRS = ["eot_data/english", "eot_data/hindi"]


def load_all(dirs=DIRS):
    X_all, y_all, g_all, keys_all, lang_all = [], [], [], [], []
    for d in dirs:
        rows = list(csv.DictReader(open(os.path.join(d, "labels.csv"))))
        X, keys = build_matrix(d, rows)
        lab = {(r["turn_id"], r["pause_index"]): r["label"] for r in rows}
        y = np.array([1 if lab[k] == "eot" else 0 for k in keys])
        X_all.append(X); y_all.append(y)
        g_all += [k[0] for k in keys]
        keys_all += keys
        lang_all += [d] * len(keys)
    return (np.vstack(X_all), np.concatenate(y_all), np.array(g_all),
            keys_all, np.array(lang_all))


def hold_weights(y, keys, dirs=DIRS):
    """Holds are weighted by their duration: only holds longer than the
    agent's action delay can cause a false cutoff, so long holds matter
    far more. Duration is used ONLY as a training weight, never a feature."""
    dur = {}
    for d in dirs:
        for r in csv.DictReader(open(os.path.join(d, "labels.csv"))):
            dur[(r["turn_id"], r["pause_index"])] =                 float(r["pause_end"]) - float(r["pause_start"])
    w = np.ones(len(y))
    for i, k in enumerate(keys):
        if y[i] == 0:
            w[i] = 0.2 + 4.0 * min(dur[k], 1.6)
    return w


def members(seed):
    return [
        GradientBoostingClassifier(n_estimators=400, learning_rate=0.04,
                                   max_depth=4, subsample=0.7,
                                   min_samples_leaf=6, random_state=seed),
        GradientBoostingClassifier(n_estimators=600, learning_rate=0.03,
                                   max_depth=2, subsample=0.8,
                                   min_samples_leaf=10, random_state=seed),
        HistGradientBoostingClassifier(max_iter=300, learning_rate=0.05,
                                       max_depth=3, l2_regularization=1.0,
                                       random_state=seed),
    ]


def main():
    X, y, groups, keys, langs = load_all()
    print(f"{len(y)} pauses, {y.mean():.2%} eot, {X.shape[1]} features")
    w = hold_weights(y, keys)

    oof = np.zeros(len(y))
    for tr, te in GroupKFold(5).split(X, y, groups):
        ps = []
        for s in range(3):
            for m in members(s):
                m.fit(X[tr], y[tr], sample_weight=w[tr])
                ps.append(m.predict_proba(X[te])[:, 1])
        oof[te] = np.mean(ps, axis=0)

    for d in DIRS:
        sel = langs == d
        out = f"oof_{os.path.basename(d)}.csv"
        with open(out, "w", newline="") as fh:
            wcsv = csv.writer(fh); wcsv.writerow(["turn_id", "pause_index", "p_eot"])
            for k, p in zip([keys[i] for i in np.where(sel)[0]], oof[sel]):
                wcsv.writerow([k[0], k[1], f"{p:.6f}"])
        print("wrote", out)

    final = []
    for s in range(3):
        for m in members(s):
            m.fit(X, y, sample_weight=w)
            final.append(m)
    with open("model.pkl", "wb") as fh:
        pickle.dump(final, fh)
    print("saved model.pkl with", len(final), "members")


if __name__ == "__main__":
    main()
